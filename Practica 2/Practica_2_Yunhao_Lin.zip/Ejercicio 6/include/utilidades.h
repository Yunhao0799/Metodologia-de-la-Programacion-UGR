#ifndef UTILIDADES_H
#define UTILIDADES_H

bool multiplicar(double matriz1[][10], int fila1, int col1, double matriz2[][10], int fila2, int col2, double salida[][10], int &filaS, int &colS);
void mostrarMatriz(double matriz[][10], int fil, int col);

#endif
