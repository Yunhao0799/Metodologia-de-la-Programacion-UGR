#ifndef UTILIDADES_H
#define URILIDADES_H

bool insertarCadena(char *entrada, char *insertar, int posicion, char *resultado);

#endif
