#ifndef UTILIDADES_H
#define UTILIDADES_H
#include <iostream>

#include "Valor.h"

int combinarSuma(Valor *v1, int tam1, Valor *v2, int tam2, Valor *salida);
void mostrarContenido(Valor array[], int tam);

#endif
