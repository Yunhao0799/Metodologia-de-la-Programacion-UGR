#ifndef UTILIDADES_H
#define UTILIDADES_H
#include<iostream>

int mezclar (double array1[], int tam1, double array2[], int tam2, double salida[]);
void ordenavector(double array[], int tam);
void imprimirArray(double array[], int tam);
bool buscarepe (double array[], int tam, double elemento);

#endif