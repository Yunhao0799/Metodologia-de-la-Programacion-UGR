#ifndef UTILIDADES_H
#define UTILIDADES_H

#include<iostream>

using namespace std;

int localizarSubcadena(char cadena[], char subcadena[]);


#endif
