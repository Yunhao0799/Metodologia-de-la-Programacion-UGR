#ifndef UTILIDADES_H
#define UTILIDADES_H
#include<iostream>

using namespace std;

void obtenerMayorSecuenciaMonotonaCreciente( int array[], int util_array, int salida[], int &util_salida);
void imprimirArray (int array[], int tam);
int ascendentesDesdei (int array[], int tam, int posicion);


#endif
